// background.js - LLM Smart Bookmarks
console.log('LLM Bookmarks (Background): Script started successfully!');

// 添加错误处理包装器
const handleError = (error, context) => {
  console.error(`LLM Bookmarks (Background): Error in ${context}:`, error);
  return { success: false, error: error.message };
};

// 添加消息处理包装器
const handleMessage = async (tabId, message) => {
  try {
    return await chrome.tabs.sendMessage(tabId, message);
  } catch (error) {
    if (chrome.runtime.lastError) {
      console.error(
        'LLM Bookmarks (Background): Error sending message:',
        chrome.runtime.lastError.message
      );
    }
    return { success: false, error: error.message };
  }
};

// 优化命令监听器
chrome.commands.onCommand.addListener(async (command, tab) => {
  console.log(`Command received in background: ${command}`);

  if (!tab || !tab.id) {
    console.warn("Command received but no active tab found or tab ID is missing. Cannot send message.");
    return;
  }
  
  if (tab.url && (tab.url.startsWith('chrome://') || tab.url.startsWith('https://chrome.google.com/webstore'))) {
      console.log(`Command '${command}' ignored on restricted page: ${tab.url}`);
      return; // Do not attempt to send messages to restricted pages
  }

  let actionToContent;
  let bookmarkDetail = {}; // For commands that need to specify which bookmark

  switch (command) {
    case 'navigate-to-primary-bookmark': // This was your existing command
      actionToContent = 'navigateToPrimaryBookmarkAction'; // Keeping consistent with your content.js
      break;
    case 'navigate-to-single-bookmark':
      actionToContent = 'navigateToSpecificBookmarkByMode';
      bookmarkDetail = { mode: 'single' };
      break;
    case 'navigate-to-multi-bookmark-1':
      actionToContent = 'navigateToSpecificBookmarkByMode';
      bookmarkDetail = { mode: 'multi', index: 1 }; // 1-based index
      break;
    case 'navigate-to-multi-bookmark-2':
      actionToContent = 'navigateToSpecificBookmarkByMode';
      bookmarkDetail = { mode: 'multi', index: 2 };
      break;
    case 'navigate-to-multi-bookmark-3':
      actionToContent = 'navigateToSpecificBookmarkByMode';
      bookmarkDetail = { mode: 'multi', index: 3 };
      break;
    // case '_execute_action': // This is for the popup, usually handled automatically
    //   console.log("Popup action command triggered, no message to content script needed from here.");
    //   return;
    default:
      console.warn(`Unknown command: ${command}`);
      return; // Exit if the command isn't recognized
  }

  if (actionToContent) {
    console.log(`Sending message to tab ${tab.id} for action: ${actionToContent} with details:`, bookmarkDetail);
    try {
      const response = await chrome.tabs.sendMessage(tab.id, {
        action: actionToContent,
        ...bookmarkDetail
      });
      if (chrome.runtime.lastError) {
        // Log error if sending message failed (e.g., no content script listening)
        console.error(`Error sending message for command ${command}: ${chrome.runtime.lastError.message} on tab ${tab.id} (URL: ${tab.url})`);
      } else {
        console.log("Message sent and content script responded:", response);
      }
    } catch (error) {
      console.error(`Exception when sending message for command ${command}: ${error} on tab ${tab.id} (URL: ${tab.url})`);
    }
  }
});

// 添加安装/更新处理
chrome.runtime.onInstalled.addListener((details) => {
  const reason = details.reason || 'unknown';
  console.log(`LLM Smart Bookmarks extension ${reason}. Version: ${chrome.runtime.getManifest().version}`);
  
  // 可以在这里添加初始化存储或其他设置
  if (reason === 'install') {
    chrome.storage.local.set({
      globalPinningModePreference: 'multi',
      version: chrome.runtime.getManifest().version
    });
  } else if (reason === 'update') {
    const oldVersion = details.previousVersion;
    const newVersion = chrome.runtime.getManifest().version;
    console.log(`LLM Smart Bookmarks updated from ${oldVersion} to ${newVersion}.`);
  }
});