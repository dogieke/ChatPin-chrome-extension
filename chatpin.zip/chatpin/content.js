// content.js - LLM Smart Bookmarks (Aggressive Debugging & Simplified Init)

// Helper function for safe storage operations
async function safeStorageGet(keys) {
  try {
    const result = await chrome.storage.local.get(keys);
    if (chrome.runtime.lastError) {
      console.error('LLM Bookmarks: Storage get error (lastError):', chrome.runtime.lastError.message);
      return Array.isArray(keys) ? {} : undefined; // Mimic behavior for missing keys
    }
    return result;
  } catch (error) {
    console.error('LLM Bookmarks: Storage get error (catch):', error);
    return Array.isArray(keys) ? {} : undefined;
  }
}

async function safeStorageSet(data) {
  try {
    await chrome.storage.local.set(data);
    if (chrome.runtime.lastError) {
      console.error('LLM Bookmarks: Storage set error (lastError):', chrome.runtime.lastError.message);
      return false;
    }
    return true;
  } catch (error) {
    console.error('LLM Bookmarks: Storage set error (catch):', error);
    return false;
  }
}

async function safeStorageRemove(keys) {
  try {
    await chrome.storage.local.remove(keys);
    if (chrome.runtime.lastError) {
      console.error('LLM Bookmarks: Storage remove error (lastError):', chrome.runtime.lastError.message);
      return false;
    }
    return true;
  } catch (error) {
    console.error('LLM Bookmarks: Storage remove error (catch):', error);
    return false;
  }
}


class BookmarkManager {
  constructor() {
    this.activeSingleBookmark = null;
    this.multipleBookmarks = new Map();
    this.multiModePinIdCounter = 0;
    this.currentPinningMode = 'multi'; // Default, will be overwritten by global preference

    this.pageKeySuffix = this._sanitizeUrlForKey(window.location.origin + window.location.pathname);

    this.SINGLE_BOOKMARK_DOM_ID = 'llm-active-bookmark-pin';
    this.MULTI_BOOKMARK_ID_PREFIX = 'llm-multi-pin-';

    this.GLOBAL_DEFAULT_MODE_KEY = 'globalPinningModePreference';

    console.log(
      `%cLLM Bookmarks: NEW BookmarkManager INSTANCE CREATED %c
      - Target Page Key Suffix: ${this.pageKeySuffix}
      - Based on Full URL: ${window.location.href}`,
      "background-color: blue; color: white; font-weight: bold; padding: 2px 5px;",
      "background-color: lightblue; color: black; padding: 2px 5px;"
    );

    // 添加防抖和节流控制
    this._debounceTimers = new Map();
    this._throttleTimers = new Map();
    
    // 添加性能监控
    this._performanceMetrics = {
      storageOperations: 0,
      domOperations: 0,
      lastOperationTime: Date.now()
    };
  }

  _sanitizeUrlForKey(urlInput) {
    console.log(
      `%cLLM Bookmarks: _sanitizeUrlForKey INPUT %c- Raw URL for key base: '${urlInput}'`,
      "background-color: #f0ad4e; color: white; font-weight: bold; padding: 2px 5px;",
      "background-color: #fcf8e3; color: #8a6d3b; padding: 2px 5px;"
    );
    
    // 修改 URL 处理逻辑，移除查询参数和哈希
    let key = String(urlInput).replace(/^https?:\/\//, '');
    key = key.split('?')[0].split('#')[0];
    key = key.replace(/[^a-zA-Z0-9_.\-]/g, '_');
    const finalKey = key.substring(0, 120);
    
    console.log(
      `%cLLM Bookmarks: _sanitizeUrlForKey OUTPUT %c- Sanitized Key Part: '${finalKey}'`,
      "background-color: #5cb85c; color: white; font-weight: bold; padding: 2px 5px;",
      "background-color: #dff0d8; color: #3c763d; padding: 2px 5px;"
    );
    return finalKey;
  }

  async _initAsync() {
    try {
      // Load mode from global preference
      const modeData = await safeStorageGet(this.GLOBAL_DEFAULT_MODE_KEY);
      this.currentPinningMode = (modeData && modeData[this.GLOBAL_DEFAULT_MODE_KEY]) || 'multi'; // Default to multi if not set
      // Save the determined (or default) mode back globally if it wasn't found, to establish a global default
      if (!(modeData && modeData[this.GLOBAL_DEFAULT_MODE_KEY])) {
        await safeStorageSet({ [this.GLOBAL_DEFAULT_MODE_KEY]: this.currentPinningMode });
      }
      
      console.log(`LLM Bookmarks: Global mode for ${this.pageKeySuffix} set to '${this.currentPinningMode}'.`);
      
      // Bookmarks are session-only, so no loading from storage.
      // Clear any DOM elements that might persist from browser's bfcache or similar
      document.querySelectorAll(`span#${this.SINGLE_BOOKMARK_DOM_ID}, span[id^="${this.MULTI_BOOKMARK_ID_PREFIX}"]`)
        .forEach(p => p.remove());
      this.activeSingleBookmark = null;
      this.multipleBookmarks.clear();
      this.multiModePinIdCounter = 0;

      await this._refreshPinsDOM(); // Ensure container is ready, will be empty.
    } catch (error) {
      console.error(`LLM Bookmarks: Error during _initAsync for ${this.pageKeySuffix}:`, error);
    }
    this.setupSelectionListener();
  }

  async loadDataForCurrentMode() {
    console.log(`LLM Bookmarks: loadDataForCurrentMode for ${this.pageKeySuffix}, mode: ${this.currentPinningMode}`);
    // This function is now primarily for ensuring the DOM is clean and reflects the current mode,
    // but bookmarks themselves are not loaded from storage.
    document.querySelectorAll(`span#${this.SINGLE_BOOKMARK_DOM_ID}, span[id^="${this.MULTI_BOOKMARK_ID_PREFIX}"]`)
        .forEach(p => p.remove());

    // Reset in-memory bookmark data when mode potentially changes or on initial load
    this.activeSingleBookmark = null;
    this.multipleBookmarks.clear();
    this.multiModePinIdCounter = 0;
        
    await this._refreshPinsDOM();
  }

  _ensureSinglePinDOM() {
    if (this.currentPinningMode === 'single' && this.activeSingleBookmark) {
      let pinElement = document.getElementById(this.SINGLE_BOOKMARK_DOM_ID);
      if (pinElement) {
        pinElement.innerHTML = '📌';
        pinElement.title = '点击删除此书签';
        this._addDeleteListenerToPin(pinElement, this.SINGLE_BOOKMARK_DOM_ID);
      }
    }
  }

  async _renumberMultiPinsAndUpdateDOM() {
    const sortedBookmarks = Array.from(this.multipleBookmarks.values()).sort((a, b) => a.timestamp - b.timestamp);
    const newMap = new Map();
    let currentDisplayIndex = 1;
    for (const bmData of sortedBookmarks) {
      const updatedBm = { ...bmData, displayIndex: currentDisplayIndex };
      newMap.set(bmData.id, updatedBm);
      let pinElement = document.getElementById(bmData.id);
      if (pinElement) {
          pinElement.innerHTML = `📌 <b>${currentDisplayIndex}</b>`;
          pinElement.title = `点击删除书签 ${currentDisplayIndex}`;
          this._addDeleteListenerToPin(pinElement, bmData.id);
      }
      currentDisplayIndex++;
    }
    this.multipleBookmarks = newMap;
  }

  async switchToMode(newMode) {
    console.log(`LLM Bookmarks: switchToMode to '${newMode}' for ${this.pageKeySuffix}.`);
    if (this.currentPinningMode === newMode) return;
    const oldMode = this.currentPinningMode;
    this.currentPinningMode = newMode;

    if (oldMode === 'single') document.getElementById(this.SINGLE_BOOKMARK_DOM_ID)?.remove();
    else document.querySelectorAll(`span[id^="${this.MULTI_BOOKMARK_ID_PREFIX}"]`).forEach(pin => pin.remove());

    // Clear in-memory bookmarks when switching modes
    this.activeSingleBookmark = null;
    this.multipleBookmarks.clear();
    this.multiModePinIdCounter = 0;

    // Save the new mode to global preferences
    await safeStorageSet({ [this.GLOBAL_DEFAULT_MODE_KEY]: newMode });

    await this._refreshPinsDOM(); // Refresh DOM, which will be empty for bookmarks
    this.showNotification(`已切换到全局 ${this.currentPinningMode === 'single' ? '单图钉' : '多图钉'} 模式。`);
  }

  setupSelectionListener() {
    console.log('LLM Bookmarks: setupSelectionListener called.');

    document.addEventListener('mouseup', (e) => {
      console.log('LLM Bookmarks: Mouseup event detected.');

      const activeEl = document.activeElement;
      if (activeEl && (activeEl.tagName === 'INPUT' || activeEl.tagName === 'TEXTAREA' || activeEl.isContentEditable)) {
        const selectionInEditable = window.getSelection();
        if (selectionInEditable && !selectionInEditable.isCollapsed && activeEl.contains(selectionInEditable.anchorNode) && activeEl.contains(selectionInEditable.focusNode)) {
            console.log('LLM Bookmarks: Text selected inside an input or contentEditable, hiding option.');
            this.hideBookmarkOption(); return;
        }
      }
      if (e.target.closest('.bookmark-pin-option') || e.target.closest('.bookmark-pin') || (this.currentPinningMode === 'single' && e.target.id === this.SINGLE_BOOKMARK_DOM_ID) || (this.currentPinningMode === 'multi' && e.target.closest(`span[id^="${this.MULTI_BOOKMARK_ID_PREFIX}"]`))) {
        console.log('LLM Bookmarks: Clicked on an existing pin or the option itself.');
        return;
      }
      const selection = window.getSelection();

      console.log('LLM Bookmarks: Selection object:', selection);
      if (selection) {
        console.log('LLM Bookmarks: selection.isCollapsed:', selection.isCollapsed);
        const currentTrimmedText = selection.toString().trim();
        console.log('LLM Bookmarks: selection.toString().trim():', `"${currentTrimmedText}"`);
        console.log('LLM Bookmarks: selection.toString().trim().length > 0:', currentTrimmedText.length > 0);
      }


      if (selection && !selection.isCollapsed && selection.toString().trim().length > 0) {
        console.log('LLM Bookmarks: Conditions met, calling showBookmarkOption.');
        const rangeForBookmark = selection.getRangeAt(0).cloneRange();
        const selectedTextForBookmark = selection.toString().trim();
        this.showBookmarkOption(rangeForBookmark, selectedTextForBookmark);
      } else {
        console.log('LLM Bookmarks: Conditions NOT met for showing bookmark option, hiding.');
        this.hideBookmarkOption();
      }
    });
    document.addEventListener('mousedown', (e) => {
      if (!e.target.closest('.bookmark-pin-option')) {
        this.hideBookmarkOption();
      }
    });
    console.log('LLM Bookmarks: Mouseup and Mousedown listeners attached in setupSelectionListener.');
   }

  showBookmarkOption(range, selectedText) {
    console.log('LLM Bookmarks: showBookmarkOption called with selectedText:', `"${selectedText}"`);

    this.hideBookmarkOption();
    const rect = range.getBoundingClientRect();
    console.log('LLM Bookmarks: Pin option position rect:', rect);

    const pinOption = document.createElement('div');
    pinOption.className = 'bookmark-pin-option';
    pinOption.innerHTML = '📌';
    pinOption.title = this.currentPinningMode === 'single' ? 'Set as the active bookmark' : 'Add new bookmark';
    pinOption.style.position = 'fixed';
    pinOption.style.top = (rect.bottom) + 'px';
    pinOption.style.left = (rect.left + (rect.width / 2)) + 'px';
    pinOption.style.transform = 'translateX(-50%)';
    pinOption.style.zIndex = '10000';

    console.log('LLM Bookmarks: Created pinOption element:', pinOption);
    console.log('LLM Bookmarks: Pin option style top:', pinOption.style.top, 'left:', pinOption.style.left);


    pinOption.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      console.log('LLM Bookmarks: Pin option (the 📌 button next to text) was clicked.');
      this.createOrUpdateBookmark(selectedText, range);
      this.hideBookmarkOption();
    });
    document.body.appendChild(pinOption);
    console.log('LLM Bookmarks: Pin option appended to document body.');
   }

  hideBookmarkOption() {
    const existingOption = document.querySelector('.bookmark-pin-option');
    if (existingOption) existingOption.remove();
   }

  async createOrUpdateBookmark(textForBookmark, range) {
    const selectedTextRaw = textForBookmark;
    let bookmarkText = "";

    if (!selectedTextRaw || selectedTextRaw.length === 0) {
      console.warn("LLM Bookmarks (createOrUpdateBookmark): Attempted to create bookmark with empty text. Aborting.");
      this.showNotification("Cannot create bookmark with empty text.");
      return;
    }

    if (this.currentPinningMode === 'single') {
        const words = selectedTextRaw.split(/\s+/);
        const snippet = words.slice(0, 7).join(" ");
        bookmarkText = words.length > 7 ? snippet + "..." : snippet;
    } else { // Multi-pin mode
        bookmarkText = selectedTextRaw.substring(0, 10);
        if (selectedTextRaw.length > 10) {
            bookmarkText += "...";
        }
    }

    if (this.currentPinningMode === 'single') {
        document.getElementById(this.SINGLE_BOOKMARK_DOM_ID)?.remove();
        const pin = document.createElement('span');
        pin.className = 'bookmark-pin';
        pin.id = this.SINGLE_BOOKMARK_DOM_ID;
        pin.innerHTML = '📌';
        pin.title = '点击删除此书签';
        pin.setAttribute('data-llm-bookmark-id', this.SINGLE_BOOKMARK_DOM_ID);
        
        try {
            const bookmarkRange = range.cloneRange();
            bookmarkRange.collapse(false);
            bookmarkRange.insertNode(pin);
            this.activeSingleBookmark = { 
                id: this.SINGLE_BOOKMARK_DOM_ID, 
                text: bookmarkText, 
                timestamp: Date.now() 
            };
            this._addDeleteListenerToPin(pin, this.SINGLE_BOOKMARK_DOM_ID);
            window.getSelection()?.removeAllRanges();
            this.showNotification('此页面的活动书签已设置！点击图钉删除。');
        } catch (error) {
            console.error('LLM Bookmarks (Single Mode): Error creating/replacing bookmark:', error);
            this.showNotification('设置书签时出错。请检查控制台。');
        }
    } else {
        this.multiModePinIdCounter++;
        const bookmarkId = this.MULTI_BOOKMARK_ID_PREFIX + this.multiModePinIdCounter;
        const pin = document.createElement('span');
        pin.className = 'bookmark-pin';
        pin.id = bookmarkId;
        pin.title = `点击删除书签`;
        pin.setAttribute('data-llm-bookmark-id', bookmarkId);
        
        try {
            const bookmarkRange = range.cloneRange();
            bookmarkRange.collapse(false);
            bookmarkRange.insertNode(pin);
            const bookmarkData = { 
                id: bookmarkId, 
                text: bookmarkText, 
                timestamp: Date.now(), 
                displayIndex: 0 
            };
            this.multipleBookmarks.set(bookmarkId, bookmarkData);
            await this._renumberMultiPinsAndUpdateDOM();
            window.getSelection()?.removeAllRanges();
            const finalDisplayIndex = this.multipleBookmarks.get(bookmarkId)?.displayIndex || '';
            this.showNotification(`此页面的书签 ${finalDisplayIndex} 已创建！点击图钉删除。`);
        } catch (error) {
            console.error('LLM Bookmarks (Multi Mode): Error creating bookmark:', error);
            this.showNotification('创建书签时出错。请检查控制台。');
        }
    }
  }

  _addDeleteListenerToPin(pinElement, bookmarkId) {
    if (!pinElement) return;
    
    // 移除旧的事件监听器
    const oldPin = document.getElementById(bookmarkId);
    if (oldPin) {
        const newPin = oldPin.cloneNode(true);
        oldPin.parentNode?.replaceChild(newPin, oldPin);
        pinElement = newPin;
    }
    
    // 添加新的事件监听器
    pinElement.addEventListener('click', (event) => {
        event.preventDefault();
        event.stopPropagation();
        this.deleteBookmarkById(bookmarkId);
    });
  }

  async deleteBookmarkById(bookmarkId) {
    const pinElement = document.getElementById(bookmarkId);
    if (this.currentPinningMode === 'single' && bookmarkId === this.SINGLE_BOOKMARK_DOM_ID) {
      if (pinElement) pinElement.remove();
      this.activeSingleBookmark = null;
      this.showNotification('此页面的活动书签已删除！');
    } else if (this.currentPinningMode === 'multi' && bookmarkId.startsWith(this.MULTI_BOOKMARK_ID_PREFIX)) {
      if (this.multipleBookmarks.has(bookmarkId)) {
        if (pinElement) pinElement.remove();
        this.multipleBookmarks.delete(bookmarkId);
        await this._renumberMultiPinsAndUpdateDOM();
        this.showNotification('此页面的书签已删除！');
      } else if (pinElement) { pinElement.remove(); this.showNotification('书签图钉已移除（未找到数据）。'); }
    }
   }

  async _refreshPinsDOM() {
    this._performanceMetrics.domOperations++;
    const startTime = performance.now();
    
    try {
      // 使用 DocumentFragment 优化 DOM 操作
      const fragment = document.createDocumentFragment();
      
      if (this.currentPinningMode === 'single') {
        this._ensureSinglePinDOM();
      } else {
        // 批量处理多个书签
        const sortedBookmarks = Array.from(this.multipleBookmarks.values())
          .sort((a, b) => (a.displayIndex || Infinity) - (b.displayIndex || Infinity));
        
        for (const bookmark of sortedBookmarks) {
          const pinElement = this._createPinElement(bookmark);
          fragment.appendChild(pinElement);
        }
      }
      
      // 一次性更新 DOM
      const container = document.getElementById('llm-bookmarks-container') || 
        this._createBookmarksContainer();
      container.innerHTML = '';
      container.appendChild(fragment);
      
      const endTime = performance.now();
      console.log(`LLM Bookmarks: DOM refresh completed in ${endTime - startTime}ms`);
    } catch (error) {
      console.error('LLM Bookmarks: Error refreshing pins DOM:', error);
    }
  }

  // 创建书签容器
  _createBookmarksContainer() {
    const container = document.createElement('div');
    container.id = 'llm-bookmarks-container';
    container.style.cssText = `
      position: fixed;
      right: 20px;
      top: 20px;
      z-index: 9999;
      display: flex;
      flex-direction: column;
      gap: 5px;
    `;
    document.body.appendChild(container);
    return container;
  }

  // 创建单个书签元素
  _createPinElement(bookmark) {
    const pinElement = document.createElement('span');
    pinElement.id = bookmark.id;
    pinElement.className = 'llm-bookmark-pin';
    pinElement.innerHTML = '📌';
    pinElement.title = bookmark.text || '点击跳转到书签位置';
    pinElement.setAttribute('data-llm-bookmark-id', bookmark.id);
    
    // 添加事件监听器
    this._addDeleteListenerToPin(pinElement, bookmark.id);
    pinElement.addEventListener('click', () => this.scrollToBookmark(bookmark.id));
    
    return pinElement;
  }

  // 优化滚动到书签位置
  scrollToBookmark(bookmarkId) {
    this._throttle('scroll', () => {
        try {
            const bookmark = this.currentPinningMode === 'single' 
                ? this.activeSingleBookmark 
                : this.multipleBookmarks.get(bookmarkId);
            
            if (!bookmark) {
                console.warn(`LLM Bookmarks: Bookmark not found for ID: ${bookmarkId}`);
                return;
            }
            
            // 首先尝试通过 data-llm-bookmark-id 属性查找
            let element = document.querySelector(`[data-llm-bookmark-id="${bookmarkId}"]`);
            
            // 如果找不到，尝试通过 ID 查找
            if (!element) {
                element = document.getElementById(bookmarkId);
            }
            
            if (element) {
                element.scrollIntoView({ behavior: 'smooth', block: 'center' });
                element.classList.add('llm-bookmark-highlight');
                setTimeout(() => element.classList.remove('llm-bookmark-highlight'), 2000);
                console.log(`LLM Bookmarks: Successfully scrolled to bookmark: ${bookmarkId}`);
            } else {
                console.warn(`LLM Bookmarks: Could not find element for bookmark: ${bookmarkId}`);
                this.showNotification('无法找到书签位置，可能已被删除或移动。');
            }
        } catch (error) {
            console.error('LLM Bookmarks: Error scrolling to bookmark:', error);
            this.showNotification('跳转到书签时出错。');
        }
    });
  }

  showNotification(message) {
    const existingNotification = document.querySelector('.bookmark-notification');
    if (existingNotification) existingNotification.remove();
    const notification = document.createElement('div');
    notification.className = 'bookmark-notification';
    notification.textContent = message;
    document.body.appendChild(notification);
    setTimeout(() => notification.remove(), 3000);
   }

  // 添加防抖方法
  _debounce(key, fn, delay = 300) {
    if (this._debounceTimers.has(key)) {
      clearTimeout(this._debounceTimers.get(key));
    }
    this._debounceTimers.set(key, setTimeout(() => {
      fn();
      this._debounceTimers.delete(key);
    }, delay));
  }

  // 添加节流方法
  _throttle(key, fn, limit = 300) {
    if (!this._throttleTimers.has(key)) {
      fn();
      this._throttleTimers.set(key, setTimeout(() => {
        this._throttleTimers.delete(key);
      }, limit));
    }
  }
}

// --- Global Scope & Initialization ---
let bookmarkManager = null;

// Helper function to wait for DOM readiness
function waitForDOM(callback, maxRetries = 10, delay = 100) {
  if (document.readyState === 'complete' || document.readyState === 'interactive') {
    console.log("LLM Bookmarks: DOM ready, proceeding with callback.");
    callback();
  } else if (maxRetries > 0) {
    console.log(`LLM Bookmarks: DOM not ready, retrying in ${delay}ms... (${maxRetries} retries left)`);
    setTimeout(() => waitForDOM(callback, maxRetries - 1, delay), delay);
  } else {
    console.error("LLM Bookmarks: DOM did not become ready after multiple retries. Initialization might fail.");
    // Optionally, still call the callback, or handle critical failure
    callback(); // Attempting callback even if DOM might not be fully ready after retries
  }
}

async function initializeManagerLogic() {
  const currentOrigin = window.location.origin;
  const currentPathname = window.location.pathname;

  // Temporarily create a BookmarkManager instance just to use its _sanitizeUrlForKey method.
  // This will log "NEW BookmarkManager INSTANCE" for the temp instance.
  const tempSanitizer = new BookmarkManager();
  const currentSanitizedKey = tempSanitizer._sanitizeUrlForKey(currentOrigin + currentPathname);

  console.log(
    `%cLLM Bookmarks: initializeManagerLogic CALLED %c
    - Current Full URL: ${window.location.href}
    - Calculated Key for this URL: ${currentSanitizedKey}
    - Existing manager instance: ${bookmarkManager ? 'Yes' : 'No'}
    - Existing manager key (if any): ${bookmarkManager ? bookmarkManager.pageKeySuffix : 'N/A'}`,"background-color: #28a745; color: white; font-weight: bold; padding: 2px 5px;","background-color: #d4edda; color: #155724; padding: 2px 5px;"
  );

  if (!bookmarkManager || bookmarkManager.pageKeySuffix !== currentSanitizedKey) {
    if (bookmarkManager && bookmarkManager.pageKeySuffix !== currentSanitizedKey) {
        console.log(
            `%cLLM Bookmarks: initializeManagerLogic - URL key MISMATCH. %c
            - Existing Manager Key: ${bookmarkManager.pageKeySuffix}
            - Current URL Key for re-init: ${currentSanitizedKey}
            - Action: Creating NEW BookmarkManager instance.`,"background-color: #ffc107; color: black; font-weight: bold; padding: 2px 5px;","background-color: #fff3cd; color: #856404; padding: 2px 5px;"
        );
    } else if (!bookmarkManager) {
        console.log(
            `%cLLM Bookmarks: initializeManagerLogic - No existing manager. %c
            - Current URL Key for init: ${currentSanitizedKey}
            - Action: Creating NEW BookmarkManager instance.`,"background-color: #007bff; color: white; font-weight: bold; padding: 2px 5px;","background-color: #cce5ff; color: #004085; padding: 2px 5px;"
        );
    }

    bookmarkManager = new BookmarkManager(); // This creates a new manager with the currentSanitizedKey
    await bookmarkManager._initAsync(); // _initAsync uses the key from the new instance
  } else {
    console.log(
        `%cLLM Bookmarks: initializeManagerLogic - Manager already exists and key matches. %c
        - Current URL Key: ${currentSanitizedKey}
        - Action: Using existing manager. No re-init.`,"background-color: #6c757d; color: white; font-weight: bold; padding: 2px 5px;","background-color: #e9ecef; color: #343a40; padding: 2px 5px;"
    );
  }
}

// Wrapped initialization function
async function initializeManager() {
  await waitForDOM(async () => { // waitForDOM is now awaited
    await initializeManagerLogic();
  });
}


// SPA Navigation Detection & Handling
function spaNavigationHandler(eventSource) {
    console.log(
        `%cLLM Bookmarks: SPA Navigation Event Detected (%c${eventSource}%c) %c
        - New location: ${location.href}.
        - Triggering initializeManager.`,"background-color: magenta; color: white; font-weight: bold; padding: 2px 5px;","background-color: pink; color: black; font-style: italic; padding: 2px 5px;","background-color: magenta; color: white; font-weight: bold; padding: 2px 5px;","background-color: #f8d7da; color: #721c24; padding: 2px 5px;"
    );
    // Directly call initializeManager, which is now async and handles DOM waiting.
    // The 150ms timeout might have been causing race conditions.
    initializeManager(); 
}
window.addEventListener('popstate', () => spaNavigationHandler('popstate'));

(function(history){
    const originalPushState = history.pushState;
    history.pushState = function() {
        const result = originalPushState.apply(history, arguments);
        spaNavigationHandler('pushState');
        return result;
    };
    const originalReplaceState = history.replaceState;
    history.replaceState = function() {
        const result = originalReplaceState.apply(history, arguments);
        spaNavigationHandler('replaceState');
        return result;
    };
})(window.history);

// Initial Load
// DOMContentLoaded is already a form of waiting for DOM, but waitForDOM adds retries.
// We will call initializeManager directly, which now internally uses waitForDOM.
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => {
    console.log("LLM Bookmarks: DOMContentLoaded - Calling initializeManager.");
    initializeManager();
  });
} else {
  console.log("LLM Bookmarks: DOM already loaded / or loading state not 'loading' - Calling initializeManager.");
  initializeManager();
}

// --- Message Listener ---
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  (async () => {
    console.log(`LLM Bookmarks (Message Listener for ${request.action}): Verifying/Re-initializing manager if needed at listener entry.`);
    
    // Crucial: Ensure the manager is up-to-date with the CURRENT page state BEFORE any action.
    // initializeManager will handle DOM readiness and create/use the correct manager instance.
    await initializeManager(); 

    // After initializeManager, bookmarkManager global variable should be the correct one for the current page.
    if (!bookmarkManager) {
        console.error("LLM Bookmarks: BookmarkManager CRITICAL FAILURE to initialize for action:", request.action);
        sendResponse({ success: false, error: "Bookmark manager component failed to load on page." });
        return;
    }
    
    // Double check current page key against the now presumably up-to-date manager.
    // This check might be redundant if initializeManager is perfectly reliable, but good for sanity.
    const currentUrlKeyForMessage = bookmarkManager._sanitizeUrlForKey(window.location.origin + window.location.pathname); // Use current manager's method
    if (bookmarkManager.pageKeySuffix !== currentUrlKeyForMessage) {
        console.error(
            `%cLLM Bookmarks (Message Listener): FATAL MISMATCH POST-INIT! %c
            - Manager Key: ${bookmarkManager.pageKeySuffix}
            - Current URL Key: ${currentUrlKeyForMessage}
            - Action: ${request.action}
            - This indicates a deeper issue in manager initialization or state handling.`,
            "background-color: red; color: white; font-weight: bold; padding: 2px 5px;",
            "background-color: #f8d7da; color: #721c24; padding: 2px 5px;"
        );
        // Attempt one more re-init as a last resort, though this state should ideally not be reached.
        await initializeManagerLogic(); 
        if (!bookmarkManager || bookmarkManager.pageKeySuffix !== currentUrlKeyForMessage) {
            sendResponse({ success: false, error: "Bookmark manager could not align with page URL after re-attempt." });
            return;
        }
        console.warn("LLM Bookmarks (Message Listener): Manager was re-aligned after initial mismatch post-init.");
    }

    // Log which manager instance (by its key) is actually handling the request.
    console.log(
        `%cLLM Bookmarks (Message Listener): Action '${request.action}' will be handled by manager with key: %c${bookmarkManager.pageKeySuffix}`,
        "background-color: #17a2b8; color: white; font-weight: bold; padding: 2px 5px;",
        "background-color: #d1ecf1; color: #0c5460; padding: 2px 5px;"
    );

    try {
      switch (request.action) {
        case 'clearAllBookmarks':
          console.log(`LLM Bookmarks (Message: clearAllBookmarks) for page ${bookmarkManager.pageKeySuffix}, mode ${bookmarkManager.currentPinningMode}`);
          try {
              // 清除 DOM 元素
              if (bookmarkManager.currentPinningMode === 'single') {
                  const singlePin = document.getElementById(bookmarkManager.SINGLE_BOOKMARK_DOM_ID);
                  if (singlePin) singlePin.remove();
                  bookmarkManager.activeSingleBookmark = null;
              } else {
                  // 清除所有多图钉
                  const pinsToRemove = Array.from(bookmarkManager.multipleBookmarks.keys());
                  for (const pinId of pinsToRemove) {
                      const pinElement = document.getElementById(pinId);
                      if (pinElement) pinElement.remove();
                  }
                  bookmarkManager.multipleBookmarks.clear();
                  bookmarkManager.multiModePinIdCounter = 0;
              }
              
              // 更新 DOM
              await bookmarkManager._refreshPinsDOM();
              
              // 显示通知
              bookmarkManager.showNotification(
                  bookmarkManager.currentPinningMode === 'single' 
                      ? '活动书签已清除！' 
                      : '所有书签已清除！'
              );
              
              // 发送成功响应
              sendResponse({ success: true });
          } catch (error) {
              console.error("LLM Bookmarks: Error clearing bookmarks:", error);
              sendResponse({ success: false, error: error.message });
          }
          break;
        case 'getBookmarks':
          let bookmarkList = [];
          const modeForList = bookmarkManager.currentPinningMode;
          if (modeForList === 'single') {
            if (bookmarkManager.activeSingleBookmark) bookmarkList.push(bookmarkManager.activeSingleBookmark);
          } else {
            if (bookmarkManager.multipleBookmarks) {
                bookmarkList.push(...Array.from(bookmarkManager.multipleBookmarks.values()).sort((a,b) => (a.displayIndex || Infinity) - (b.displayIndex || Infinity)));
            }
          }
          console.log(`LLM Bookmarks (Message: getBookmarks) for page ${bookmarkManager.pageKeySuffix}. Mode: ${modeForList}. Count: ${bookmarkList.length}`);
          sendResponse({ bookmarks: bookmarkList, mode: modeForList, pageTitle: document.title, pageUrlKey: bookmarkManager.pageKeySuffix });
          break;
        case 'navigateToPrimaryBookmarkAction':
          console.log(`LLM Bookmarks (Message: navigateToPrimaryBookmarkAction) for page ${bookmarkManager.pageKeySuffix}`);
          if (bookmarkManager.currentPinningMode === 'single' && bookmarkManager.activeSingleBookmark) {
            await bookmarkManager.scrollToBookmark(bookmarkManager.activeSingleBookmark.id);
          } else if (bookmarkManager.currentPinningMode === 'multi' && bookmarkManager.multipleBookmarks.size > 0) {
            // Navigate to the first multi-pin by sorted order if this command is used for multi-mode
            const sortedBookmarks = Array.from(bookmarkManager.multipleBookmarks.values()).sort((a,b) => (a.displayIndex || Infinity) - (b.displayIndex || Infinity));
            if (sortedBookmarks.length > 0) {
              await bookmarkManager.scrollToBookmark(sortedBookmarks[0].id);
            }
          } else {
            bookmarkManager.showNotification("No primary bookmark to navigate to.");
          }
          sendResponse({ success: true });
          break;
        case 'navigateToSpecificBookmark':
          console.log(`LLM Bookmarks (Message: navigateToSpecificBookmark) for page ${bookmarkManager.pageKeySuffix}, ID: ${request.bookmarkId}`);
          if (request.bookmarkId) await bookmarkManager.scrollToBookmark(request.bookmarkId);
          sendResponse({ success: true });
          break;
        case 'navigateToSpecificBookmarkByMode':
          console.log(`LLM Bookmarks (Message: navigateToSpecificBookmarkByMode) for page ${bookmarkManager.pageKeySuffix}, Mode: ${request.mode}, Index: ${request.index}`);
          if (request.mode === 'single') {
            if (bookmarkManager.currentPinningMode === 'single' && bookmarkManager.activeSingleBookmark) {
              await bookmarkManager.scrollToBookmark(bookmarkManager.activeSingleBookmark.id);
              sendResponse({ success: true, message: "Navigated to single bookmark." });
            } else {
              bookmarkManager.showNotification("Single pin mode not active or no bookmark set.");
              sendResponse({ success: false, error: "Single pin mode not active or no bookmark." });
            }
          } else if (request.mode === 'multi') {
            if (bookmarkManager.currentPinningMode === 'multi' && request.index && request.index > 0) {
              const sortedBookmarks = Array.from(bookmarkManager.multipleBookmarks.values()).sort((a,b) => (a.displayIndex || Infinity) - (b.displayIndex || Infinity));
              if (request.index <= sortedBookmarks.length) {
                const targetBookmark = sortedBookmarks[request.index - 1]; // 0-indexed access
                await bookmarkManager.scrollToBookmark(targetBookmark.id);
                sendResponse({ success: true, message: `Navigated to multi-bookmark index ${request.index}.` });
              } else {
                bookmarkManager.showNotification(`Bookmark at index ${request.index} not found.`);
                sendResponse({ success: false, error: `Bookmark at index ${request.index} not found.` });
              }
            } else {
              bookmarkManager.showNotification("Multi-pin mode not active or invalid index provided.");
              sendResponse({ success: false, error: "Multi-pin mode not active or invalid index." });
            }
          } else {
            sendResponse({ success: false, error: "Invalid mode for navigation." });
          }
          break;
        case 'syncModeAndData':
          console.log(`LLM Bookmarks (Message: syncModeAndData) for page ${bookmarkManager.pageKeySuffix}, newMode: ${request.newMode}`);
          if (request.newMode) {
            await bookmarkManager.switchToMode(request.newMode);
            sendResponse({ success: true, newMode: request.newMode, message: "全局默认模式已设置，当前页面已同步。" });
          } else {
            sendResponse({ success: false, error: '未指定新模式。' });
          }
          break;
        default:
          console.warn("LLM Bookmarks: Unknown action received in content.js:", request.action);
          sendResponse({ success: false, error: "Unknown action" });
          break;
      }
    } catch (error) {
        console.error(`LLM Bookmarks: Error processing message action '${request.action}' for page ${bookmarkManager ? bookmarkManager.pageKeySuffix : 'UNKNOWN_PAGE'}:`, error);
        sendResponse({ success: false, error: "Internal error: " + error.message });
    }
  })();
  return true;
});