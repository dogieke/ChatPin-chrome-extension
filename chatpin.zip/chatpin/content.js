// content.js - LLM Smart Bookmarks (Aggressive Debugging & Simplified Init)

// Helper function for safe storage operations
async function safeStorageGet(keys) {
  try {
    const result = await chrome.storage.local.get(keys);
    if (chrome.runtime.lastError) {
      console.error('LLM Bookmarks: Storage get error (lastError):', chrome.runtime.lastError.message);
      return Array.isArray(keys) ? {} : undefined; // Mimic behavior for missing keys
    }
    return result;
  } catch (error) {
    console.error('LLM Bookmarks: Storage get error (catch):', error);
    return Array.isArray(keys) ? {} : undefined;
  }
}

async function safeStorageSet(data) {
  try {
    await chrome.storage.local.set(data);
    if (chrome.runtime.lastError) {
      console.error('LLM Bookmarks: Storage set error (lastError):', chrome.runtime.lastError.message);
      return false;
    }
    return true;
  } catch (error) {
    console.error('LLM Bookmarks: Storage set error (catch):', error);
    return false;
  }
}

async function safeStorageRemove(keys) {
  try {
    await chrome.storage.local.remove(keys);
    if (chrome.runtime.lastError) {
      console.error('LLM Bookmarks: Storage remove error (lastError):', chrome.runtime.lastError.message);
      return false;
    }
    return true;
  } catch (error) {
    console.error('LLM Bookmarks: Storage remove error (catch):', error);
    return false;
  }
}


class BookmarkManager {
  constructor() {
    this.activeSingleBookmark = null;
    this.multipleBookmarks = new Map();
    this.multiModePinIdCounter = 0;
    this.currentPinningMode = 'multi'; // Default, will be overwritten by global preference

    this.pageKeySuffix = this._sanitizeUrlForKey(window.location.origin + window.location.pathname);

    this.SINGLE_BOOKMARK_DOM_ID = 'llm-active-bookmark-pin';
    this.MULTI_BOOKMARK_ID_PREFIX = 'llm-multi-pin-';

    this.GLOBAL_DEFAULT_MODE_KEY = 'globalPinningModePreference';

    console.log(
      `%cLLM Bookmarks: NEW BookmarkManager INSTANCE CREATED %c
      - Target Page Key Suffix: ${this.pageKeySuffix}
      - Based on Full URL: ${window.location.href}`,
      "background-color: blue; color: white; font-weight: bold; padding: 2px 5px;",
      "background-color: lightblue; color: black; padding: 2px 5px;"
    );

    // 添加防抖和节流控制
    this._debounceTimers = new Map();
    this._throttleTimers = new Map();
    
    // 添加性能监控
    this._performanceMetrics = {
      storageOperations: 0,
      domOperations: 0,
      lastOperationTime: Date.now()
    };
  }

  _sanitizeUrlForKey(urlInput) {
    console.log(
      `%cLLM Bookmarks: _sanitizeUrlForKey INPUT %c- Raw URL for key base: '${urlInput}'`,
      "background-color: #f0ad4e; color: white; font-weight: bold; padding: 2px 5px;",
      "background-color: #fcf8e3; color: #8a6d3b; padding: 2px 5px;"
    );
    
    let sanitizedPathKeyPart;
    const urlObj = new URL(urlInput);
    let currentPathname = urlObj.pathname;

    // Normalize: remove trailing slash if it's not the root path itself
    if (currentPathname.length > 1 && currentPathname.endsWith('/')) {
        currentPathname = currentPathname.slice(0, -1);
    }

    // Site-specific logic using the normalized currentPathname
    if (urlObj.hostname.includes('gemini.google.com')) {
        // If it's a chat page (e.g., /u/2/app/c/CHAT_ID_HERE), use the full path for uniqueness.
        if (currentPathname.startsWith('/u/2/app/c/')) { 
            sanitizedPathKeyPart = urlObj.hostname + currentPathname; // Use full path for specific chats
        } 
        // For general /app pages (like dashboard), use a more general key for that app section.
        else if (currentPathname.startsWith('/u/2/app')) { 
            sanitizedPathKeyPart = urlObj.hostname + '/u/2/app'; 
        } 
        // For other gemini paths, use hostname + full current pathname
        else {
            sanitizedPathKeyPart = urlObj.hostname + currentPathname; 
        }
    } else if (urlObj.hostname.includes('chat.deepseek.com')) {
        // If it's a specific chat session (e.g., /a/chat/s/SESSION_ID_HERE), use the full path for uniqueness.
        if (currentPathname.startsWith('/a/chat/s/')) { 
            sanitizedPathKeyPart = urlObj.hostname + currentPathname; // Use full path for specific chats
        } 
        // For other deepseek paths (e.g. root '/', or '/a/chat'), use hostname + full current pathname
        else {
            sanitizedPathKeyPart = urlObj.hostname + currentPathname;
        }
    } else {
         // Default: Use hostname + normalized pathname. 
         // Query params and hash are implicitly excluded by using urlObj.pathname.
         sanitizedPathKeyPart = urlObj.hostname + currentPathname;
    }

    // Now, replace non-allowed characters in the combined key
    let finalKeyProcessed = sanitizedPathKeyPart.replace(/[^a-zA-Z0-9_.\-]/g, '_');
    // Truncate if too long
    const finalKey = finalKeyProcessed.substring(0, 120); 
    
    console.log(
      `%cLLM Bookmarks: _sanitizeUrlForKey OUTPUT %c- Original Combined Key: '${sanitizedPathKeyPart}', Processed Key Part: '${finalKey}'`,
      "background-color: #5cb85c; color: white; font-weight: bold; padding: 2px 5px;",
      "background-color: #dff0d8; color: #3c763d; padding: 2px 5px;"
    );
    return finalKey;
  }

  async _initAsync() {
    try {
      // Load mode from global preference
      const modeData = await safeStorageGet(this.GLOBAL_DEFAULT_MODE_KEY);
      this.currentPinningMode = (modeData && modeData[this.GLOBAL_DEFAULT_MODE_KEY]) || 'multi'; // Default to multi if not set
      // Save the determined (or default) mode back globally if it wasn't found, to establish a global default
      if (!(modeData && modeData[this.GLOBAL_DEFAULT_MODE_KEY])) {
        await safeStorageSet({ [this.GLOBAL_DEFAULT_MODE_KEY]: this.currentPinningMode });
      }
      
      console.log(`LLM Bookmarks: Global mode for ${this.pageKeySuffix} set to '${this.currentPinningMode}'.`);
      
      // Bookmarks are session-only, so no loading from storage.
      // DO NOT Clear DOM elements here based on ID patterns, as this instance might be new
      // and those elements might belong to a previous manager instance for a different page key.
      // The clearing of old DOM elements for a changed pageKeySuffix should happen in initializeManagerLogic.
      // document.querySelectorAll(`span#${this.SINGLE_BOOKMARK_DOM_ID}, span[id^="${this.MULTI_BOOKMARK_ID_PREFIX}"]`)
      //   .forEach(p => p.remove());
      
      this.activeSingleBookmark = null;
      this.multipleBookmarks.clear();
      this.multiModePinIdCounter = 0;

      // Ensure the container for pins exists.
      // _refreshPinsDOM, when called by this instance, will manage its own pins within this container.
      this._createBookmarksContainer(); 

    } catch (error) {
      console.error(`LLM Bookmarks: Error during _initAsync for ${this.pageKeySuffix}:`, error);
    }
    this.setupSelectionListener();
  }

  async loadDataForCurrentMode() {
    console.log(`LLM Bookmarks: loadDataForCurrentMode for ${this.pageKeySuffix}, mode: ${this.currentPinningMode}`);
    // This function is now primarily for ensuring the DOM is clean and reflects the current mode,
    // but bookmarks themselves are not loaded from storage.
    document.querySelectorAll(`span#${this.SINGLE_BOOKMARK_DOM_ID}, span[id^="${this.MULTI_BOOKMARK_ID_PREFIX}"]`)
        .forEach(p => p.remove());

    // Reset in-memory bookmark data when mode potentially changes or on initial load
    this.activeSingleBookmark = null;
    this.multipleBookmarks.clear();
    this.multiModePinIdCounter = 0;
        
    await this._refreshPinsDOM();
  }

  _ensureSinglePinDOM() {
    if (this.currentPinningMode === 'single' && this.activeSingleBookmark) {
      let pinElement = document.getElementById(this.SINGLE_BOOKMARK_DOM_ID);
      if (pinElement) {
        pinElement.innerHTML = '📌';
        pinElement.title = '点击删除此书签';
        this._addDeleteListenerToPin(pinElement, this.SINGLE_BOOKMARK_DOM_ID);
      }
    }
  }

  async _renumberMultiPinsAndUpdateDOM() {
    const sortedBookmarks = Array.from(this.multipleBookmarks.values()).sort((a, b) => a.timestamp - b.timestamp);
    const newMap = new Map();
    let currentDisplayIndex = 1;
    for (const bmData of sortedBookmarks) {
      const updatedBm = { ...bmData, displayIndex: currentDisplayIndex };
      newMap.set(bmData.id, updatedBm);
      let pinElement = document.getElementById(bmData.id);
      if (pinElement) {
          pinElement.innerHTML = `📌 <b>${currentDisplayIndex}</b>`;
          pinElement.title = `点击删除书签 ${currentDisplayIndex}`;
          this._addDeleteListenerToPin(pinElement, bmData.id);
      }
      currentDisplayIndex++;
    }
    this.multipleBookmarks = newMap;
  }

  async switchToMode(newMode) {
    console.log(`LLM Bookmarks: switchToMode to '${newMode}' for ${this.pageKeySuffix}.`);
    if (this.currentPinningMode === newMode) return;
    const oldMode = this.currentPinningMode;
    this.currentPinningMode = newMode;

    if (oldMode === 'single') document.getElementById(this.SINGLE_BOOKMARK_DOM_ID)?.remove();
    else document.querySelectorAll(`span[id^="${this.MULTI_BOOKMARK_ID_PREFIX}"]`).forEach(pin => pin.remove());

    // Clear in-memory bookmarks when switching modes
    this.activeSingleBookmark = null;
    this.multipleBookmarks.clear();
    this.multiModePinIdCounter = 0;

    // Save the new mode to global preferences
    await safeStorageSet({ [this.GLOBAL_DEFAULT_MODE_KEY]: newMode });

    await this._refreshPinsDOM(true); // Refresh DOM, which will be empty for bookmarks
    this.showNotification(`已切换到全局 ${this.currentPinningMode === 'single' ? '单图钉' : '多图钉'} 模式。`);

    // AFTER all updates and notifications for this method:
    this._sendStateUpdateMessage('switchToMode');
  }

  setupSelectionListener() {
    console.log('LLM Bookmarks: setupSelectionListener called.');

    document.addEventListener('mouseup', (e) => {
      console.log('LLM Bookmarks: Mouseup event detected.');

      const activeEl = document.activeElement;
      if (activeEl && (activeEl.tagName === 'INPUT' || activeEl.tagName === 'TEXTAREA' || activeEl.isContentEditable)) {
        const selectionInEditable = window.getSelection();
        if (selectionInEditable && !selectionInEditable.isCollapsed && activeEl.contains(selectionInEditable.anchorNode) && activeEl.contains(selectionInEditable.focusNode)) {
            console.log('LLM Bookmarks: Text selected inside an input or contentEditable, hiding option.');
            this.hideBookmarkOption(); return;
        }
      }
      if (e.target.closest('.bookmark-pin-option') || e.target.closest('.bookmark-pin') || (this.currentPinningMode === 'single' && e.target.id === this.SINGLE_BOOKMARK_DOM_ID) || (this.currentPinningMode === 'multi' && e.target.closest(`span[id^="${this.MULTI_BOOKMARK_ID_PREFIX}"]`))) {
        console.log('LLM Bookmarks: Clicked on an existing pin or the option itself.');
        return;
      }
      const selection = window.getSelection();

      console.log('LLM Bookmarks: Selection object:', selection);
      if (selection) {
        console.log('LLM Bookmarks: selection.isCollapsed:', selection.isCollapsed);
        const currentTrimmedText = selection.toString().trim();
        console.log('LLM Bookmarks: selection.toString().trim():', `"${currentTrimmedText}"`);
        console.log('LLM Bookmarks: selection.toString().trim().length > 0:', currentTrimmedText.length > 0);
      }


      if (selection && !selection.isCollapsed && selection.toString().trim().length > 0) {
        console.log('LLM Bookmarks: Conditions met, calling showBookmarkOption.');
        const rangeForBookmark = selection.getRangeAt(0).cloneRange();
        const selectedTextForBookmark = selection.toString().trim();
        this.showBookmarkOption(rangeForBookmark, selectedTextForBookmark);
      } else {
        console.log('LLM Bookmarks: Conditions NOT met for showing bookmark option, hiding.');
        this.hideBookmarkOption();
      }
    });
    document.addEventListener('mousedown', (e) => {
      if (!e.target.closest('.bookmark-pin-option')) {
        this.hideBookmarkOption();
      }
    });
    console.log('LLM Bookmarks: Mouseup and Mousedown listeners attached in setupSelectionListener.');
   }

  showBookmarkOption(range, selectedText) {
    console.log('LLM Bookmarks: showBookmarkOption called with selectedText:', `"${selectedText}"`);

    this.hideBookmarkOption();
    const rect = range.getBoundingClientRect();
    console.log('LLM Bookmarks: Pin option position rect:', rect);

    const pinOption = document.createElement('div');
    pinOption.className = 'bookmark-pin-option';
    pinOption.innerHTML = '📌';
    pinOption.title = this.currentPinningMode === 'single' ? 'Set as the active bookmark' : 'Add new bookmark';
    pinOption.style.position = 'fixed';
    pinOption.style.top = (rect.bottom) + 'px';
    pinOption.style.left = (rect.left + (rect.width / 2)) + 'px';
    pinOption.style.transform = 'translateX(-50%)';
    pinOption.style.zIndex = '10000';

    console.log('LLM Bookmarks: Created pinOption element:', pinOption);
    console.log('LLM Bookmarks: Pin option style top:', pinOption.style.top, 'left:', pinOption.style.left);


    pinOption.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      console.log('LLM Bookmarks: Pin option (the 📌 button next to text) was clicked.');
      this.createOrUpdateBookmark(selectedText, range);
      this.hideBookmarkOption();
    });
    document.body.appendChild(pinOption);
    console.log('LLM Bookmarks: Pin option appended to document body.');
   }

  hideBookmarkOption() {
    const existingOption = document.querySelector('.bookmark-pin-option');
    if (existingOption) existingOption.remove();
   }

  async createOrUpdateBookmark(textForBookmark, range) {
    const selectedTextRaw = textForBookmark;
    let bookmarkText = "";

    if (!selectedTextRaw || selectedTextRaw.length === 0) {
      console.warn("LLM Bookmarks (createOrUpdateBookmark): Attempted to create bookmark with empty text. Aborting.");
      this.showNotification("Cannot create bookmark with empty text.");
      return;
    }

    if (this.currentPinningMode === 'single') {
        const words = selectedTextRaw.split(/\s+/);
        const snippet = words.slice(0, 7).join(" ");
        bookmarkText = words.length > 7 ? snippet + "..." : snippet;
    } else { // Multi-pin mode
        bookmarkText = selectedTextRaw.substring(0, 10);
        if (selectedTextRaw.length > 10) {
            bookmarkText += "...";
        }
    }

    if (this.currentPinningMode === 'single') {
        document.getElementById(this.SINGLE_BOOKMARK_DOM_ID)?.remove();
        const pin = document.createElement('span');
        pin.className = 'bookmark-pin';
        pin.id = this.SINGLE_BOOKMARK_DOM_ID;
        pin.innerHTML = '📌';
        pin.title = '点击删除此书签';
        pin.setAttribute('data-llm-bookmark-id', this.SINGLE_BOOKMARK_DOM_ID);
        
        try {
            const bookmarkRange = range.cloneRange();
            bookmarkRange.collapse(false);
            bookmarkRange.insertNode(pin);
            this.activeSingleBookmark = { 
                id: this.SINGLE_BOOKMARK_DOM_ID, 
                text: bookmarkText, 
                timestamp: Date.now() 
            };
            this._addDeleteListenerToPin(pin, this.SINGLE_BOOKMARK_DOM_ID);
            window.getSelection()?.removeAllRanges();
            this.showNotification('此页面的活动书签已设置！点击图钉删除。');
        } catch (error) {
            console.error('LLM Bookmarks (Single Mode): Error creating/replacing bookmark:', error);
            this.showNotification('设置书签时出错。请检查控制台。');
        }
    } else {
        this.multiModePinIdCounter++;
        const bookmarkId = this.MULTI_BOOKMARK_ID_PREFIX + this.multiModePinIdCounter;
        const pin = document.createElement('span');
        pin.className = 'bookmark-pin';
        pin.id = bookmarkId;
        pin.title = `点击删除书签`;
        pin.setAttribute('data-llm-bookmark-id', bookmarkId);
        
        try {
            const bookmarkRange = range.cloneRange();
            bookmarkRange.collapse(false);
            bookmarkRange.insertNode(pin);
            const bookmarkData = { 
                id: bookmarkId, 
                text: bookmarkText, 
                timestamp: Date.now(), 
                displayIndex: 0 
            };
            this.multipleBookmarks.set(bookmarkId, bookmarkData);
            await this._renumberMultiPinsAndUpdateDOM();
            window.getSelection()?.removeAllRanges();
            const finalDisplayIndex = this.multipleBookmarks.get(bookmarkId)?.displayIndex || '';
            this.showNotification(`此页面的书签 ${finalDisplayIndex} 已创建！点击图钉删除。`);
        } catch (error) {
            console.error('LLM Bookmarks (Multi Mode): Error creating bookmark:', error);
            this.showNotification('创建书签时出错。请检查控制台。');
        }
    }

    // AFTER all updates and notifications for this method:
    this._sendStateUpdateMessage('createOrUpdateBookmark');
  }

  _addDeleteListenerToPin(pinElement, bookmarkId) {
    if (!pinElement) return;
    
    // 移除旧的事件监听器
    const oldPin = document.getElementById(bookmarkId);
    if (oldPin) {
        const newPin = oldPin.cloneNode(true);
        oldPin.parentNode?.replaceChild(newPin, oldPin);
        pinElement = newPin;
    }
    
    // 添加新的事件监听器
    pinElement.addEventListener('click', (event) => {
        event.preventDefault();
        event.stopPropagation();
        this.deleteBookmarkById(bookmarkId);
    });
  }

  async deleteBookmarkById(bookmarkId) {
    const pinElement = document.getElementById(bookmarkId);
    if (this.currentPinningMode === 'single' && bookmarkId === this.SINGLE_BOOKMARK_DOM_ID) {
      if (pinElement) pinElement.remove();
      this.activeSingleBookmark = null;
      this.showNotification('此页面的活动书签已删除！');
    } else if (this.currentPinningMode === 'multi' && bookmarkId.startsWith(this.MULTI_BOOKMARK_ID_PREFIX)) {
      if (this.multipleBookmarks.has(bookmarkId)) {
        if (pinElement) pinElement.remove();
        this.multipleBookmarks.delete(bookmarkId);
        await this._renumberMultiPinsAndUpdateDOM();
        this.showNotification('此页面的书签已删除！');
      } else if (pinElement) { pinElement.remove(); this.showNotification('书签图钉已移除（未找到数据）。'); }
    }

    // AFTER all updates and notifications for this method:
    this._sendStateUpdateMessage('deleteBookmarkById');
  }

  async _refreshPinsDOM(isExplicitClearOperation = false) {
    this._performanceMetrics.domOperations++;
    const startTime = performance.now();
    console.log(`LLM Bookmarks: _refreshPinsDOM called. Mode: ${this.currentPinningMode}, ExplicitClear: ${isExplicitClearOperation}, MultiBookmarks: ${this.multipleBookmarks.size}, SingleBookmark: ${this.activeSingleBookmark !== null}`);
    
    try {
      const fragment = document.createDocumentFragment();
      let managerHasContentToDraw = false;
      
      const container = document.getElementById('llm-bookmarks-container') || this._createBookmarksContainer();

      if (this.currentPinningMode === 'single') {
        if (this.activeSingleBookmark) {
          this._ensureSinglePinDOM(); // This places/updates the single pin directly
          managerHasContentToDraw = true;
        } else {
          // If no single bookmark, ensure its specific DOM element is removed
          const singlePinEl = document.getElementById(this.SINGLE_BOOKMARK_DOM_ID);
          if (singlePinEl) singlePinEl.remove();
        }
        // Single mode does not clear the main container in _refreshPinsDOM, it manages its element by ID.
        // If switching TO single mode and an explicit clear was requested, the container might have old multi-pins.
        if (isExplicitClearOperation) {
            container.innerHTML = ''; // Clear container if explicit clear for single mode (e.g. mode switch)
        }

      } else { // Multi-mode
        const sortedBookmarks = Array.from(this.multipleBookmarks.values())
          .sort((a, b) => (a.displayIndex || Infinity) - (b.displayIndex || Infinity));
        
        if (sortedBookmarks.length > 0) {
          managerHasContentToDraw = true;
          for (const bookmark of sortedBookmarks) {
            const pinElement = this._createPinElement(bookmark);
            fragment.appendChild(pinElement);
          }
        }

        // For multi-mode, clear container IF:
        // 1. It's an explicit clear operation (e.g., clearAllBookmarks, switchToMode)
        // 2. OR if this manager instance actually has multi-pins to draw (needs a fresh slate)
        // This prevents an empty manager (e.g. new instance for a new page) from wiping existing DOM from a *previous* manager instance
        // UNLESS it was an explicit clear.
        if (managerHasContentToDraw || isExplicitClearOperation) {
          container.innerHTML = '';
          if (managerHasContentToDraw) {
            container.appendChild(fragment);
          }
        } 
        // If !managerHasContentToDraw AND !isExplicitClearOperation, do nothing to the container for multi-mode.
      }
      
      const endTime = performance.now();
      console.log(`LLM Bookmarks: DOM refresh completed in ${endTime - startTime}ms. Mode: ${this.currentPinningMode}, managerHasContentToDraw: ${managerHasContentToDraw}, isExplicitClear: ${isExplicitClearOperation}`);
    } catch (error) {
      console.error('LLM Bookmarks: Error refreshing pins DOM:', error);
    }
  }

  // 创建书签容器
  _createBookmarksContainer() {
    const container = document.createElement('div');
    container.id = 'llm-bookmarks-container';
    container.style.cssText = `
      position: fixed;
      right: 20px;
      top: 20px;
      z-index: 9999;
      display: flex;
      flex-direction: column;
      gap: 5px;
    `;
    document.body.appendChild(container);
    return container;
  }

  // 创建单个书签元素
  _createPinElement(bookmark) {
    const pinElement = document.createElement('span');
    pinElement.id = bookmark.id;
    pinElement.className = 'llm-bookmark-pin';
    pinElement.innerHTML = '📌';
    pinElement.title = bookmark.text || '点击跳转到书签位置';
    pinElement.setAttribute('data-llm-bookmark-id', bookmark.id);
    
    // 添加事件监听器
    this._addDeleteListenerToPin(pinElement, bookmark.id);
    pinElement.addEventListener('click', () => this.scrollToBookmark(bookmark.id));
    
    return pinElement;
  }

  // 优化滚动到书签位置
  scrollToBookmark(bookmarkId) {
    this._throttle('scroll', () => {
        try {
            const bookmark = this.currentPinningMode === 'single' 
                ? this.activeSingleBookmark 
                : this.multipleBookmarks.get(bookmarkId);
            
            if (!bookmark) {
                console.warn(`LLM Bookmarks: Bookmark not found for ID: ${bookmarkId}`);
                return;
            }
            
            // 首先尝试通过 data-llm-bookmark-id 属性查找
            let element = document.querySelector(`[data-llm-bookmark-id="${bookmarkId}"]`);
            
            // 如果找不到，尝试通过 ID 查找
            if (!element) {
                element = document.getElementById(bookmarkId);
            }
            
            if (element) {
                element.scrollIntoView({ behavior: 'smooth', block: 'center' });
                element.classList.add('llm-bookmark-highlight');
                setTimeout(() => element.classList.remove('llm-bookmark-highlight'), 2000);
                console.log(`LLM Bookmarks: Successfully scrolled to bookmark: ${bookmarkId}`);
            } else {
                console.warn(`LLM Bookmarks: Could not find element for bookmark: ${bookmarkId}`);
                this.showNotification('无法找到书签位置，可能已被删除或移动。');
            }
        } catch (error) {
            console.error('LLM Bookmarks: Error scrolling to bookmark:', error);
            this.showNotification('跳转到书签时出错。');
        }
    });
  }

  showNotification(message) {
    const existingNotification = document.querySelector('.bookmark-notification');
    if (existingNotification) existingNotification.remove();
    const notification = document.createElement('div');
    notification.className = 'bookmark-notification';
    notification.textContent = message;
    document.body.appendChild(notification);
    setTimeout(() => notification.remove(), 3000);
   }

  // 添加防抖方法
  _debounce(key, fn, delay = 300) {
    if (this._debounceTimers.has(key)) {
      clearTimeout(this._debounceTimers.get(key));
    }
    this._debounceTimers.set(key, setTimeout(() => {
      fn();
      this._debounceTimers.delete(key);
    }, delay));
  }

  // 添加节流方法
  _throttle(key, fn, limit = 300) {
    if (!this._throttleTimers.has(key)) {
      fn();
      this._throttleTimers.set(key, setTimeout(() => {
        this._throttleTimers.delete(key);
      }, limit));
    }
  }

  // Helper method to send state update to popup
  _sendStateUpdateMessage(sourceAction) {
    const latestBookmarks = [];
    if (this.currentPinningMode === 'single') {
        if (this.activeSingleBookmark) latestBookmarks.push(this.activeSingleBookmark);
    } else {
        latestBookmarks.push(...Array.from(this.multipleBookmarks.values()).sort((a,b) => (a.displayIndex || Infinity) - (b.displayIndex || Infinity)));
    }

    console.log(`LLM Bookmarks (Content Script): Sending chatPinStateUpdated from ${sourceAction}. Mode: ${this.currentPinningMode}, Count: ${latestBookmarks.length}`);
    chrome.runtime.sendMessage({
        action: 'chatPinStateUpdated',
        bookmarks: latestBookmarks,
        mode: this.currentPinningMode,
        pageUrlKey: this.pageKeySuffix,
        pageTitle: document.title 
    });
  }
}

// --- Global Scope & Initialization ---
let bookmarkManager = null;
let currentManagerKey = null; // Stores the pageKeySuffix of the currently active manager
let managerInitializationLock = null; // Promise-based lock to prevent re-entrant initialization

// Helper function to wait for DOM readiness
function waitForDOM(callback, maxRetries = 10, delay = 100) {
  if (document.readyState === 'complete' || document.readyState === 'interactive') {
    console.log("LLM Bookmarks: DOM ready, proceeding with callback.");
    callback();
  } else if (maxRetries > 0) {
    console.log(`LLM Bookmarks: DOM not ready, retrying in ${delay}ms... (${maxRetries} retries left)`);
    setTimeout(() => waitForDOM(callback, maxRetries - 1, delay), delay);
  } else {
    console.error("LLM Bookmarks: DOM did not become ready after multiple retries. Initialization might fail.");
    // Optionally, still call the callback, or handle critical failure
    callback(); // Attempting callback even if DOM might not be fully ready after retries
  }
}

// Combined and refactored initialization logic
async function initializeManager() {
    if (managerInitializationLock) {
        console.log("%cLLM Bookmarks: InitializeManager - Awaiting existing initialization lock.", "color: #666;");
        await managerInitializationLock;
    }

    let resolveLockFn;
    managerInitializationLock = new Promise(resolve => { resolveLockFn = resolve; });
    console.log("%cLLM Bookmarks: InitializeManager - Lock ACQUIRED.", "color: #666; font-weight:bold;");

    try {
        const tempSanitizer = new BookmarkManager(); // This will log its creation and sanitize call
        const newSanitizedKey = tempSanitizer._sanitizeUrlForKey(window.location.origin + window.location.pathname);

        console.log(
            `%cLLM Bookmarks: initializeManager - Core Logic Start %c
            - Current URL for Key Gen: ${window.location.href}
            - Calculated Key for this URL: ${newSanitizedKey}
            - Global bookmarkManager active: ${!!bookmarkManager}
            - Global currentManagerKey: ${currentManagerKey}`,
            "background-color: orange; color: black; font-weight: bold; padding: 2px 5px;", ""
        );

        if (!bookmarkManager || currentManagerKey !== newSanitizedKey) {
            console.log(
                `%cLLM Bookmarks: initializeManager - Condition MET for new/changed manager. %c
                - Reason: ${!bookmarkManager ? 'No existing manager' : `Key mismatch (current stored: ${currentManagerKey}, new calculated: ${newSanitizedKey})`}
                - Action: Creating NEW BookmarkManager instance for key ${newSanitizedKey}.`,
                "background-color: #ffc107; color: black; font-weight: bold; padding: 2px 5px;", ""
            );
            
            let newManagerInstance;
            await waitForDOM(async () => { 
                newManagerInstance = new BookmarkManager(); 
                await newManagerInstance._initAsync();
            });
            bookmarkManager = newManagerInstance; // Assign to global bookmarkManager
            currentManagerKey = bookmarkManager.pageKeySuffix; // Update global currentManagerKey HERE

            console.log(
                `%cLLM Bookmarks: initializeManager - NEW manager CREATED and initialized. %c
                - New active manager key: ${currentManagerKey}`,
                "background-color: #28a745; color: white; font-weight: bold; padding: 2px 5px;", ""
            );

        } else {
            console.log(
                `%cLLM Bookmarks: initializeManager - Manager exists and key matches. %c
                - Active manager key: ${currentManagerKey}
                - Action: Using existing manager. No re-init necessary by this call.`,
                "background-color: #6c757d; color: white; font-weight: bold; padding: 2px 5px;", ""
            );
        }
    } catch (error) {
        console.error("LLM Bookmarks: Critical error during initializeManager core logic:", error);
    } finally {
        if (resolveLockFn) {
            resolveLockFn();
        }
        managerInitializationLock = null;
        console.log("%cLLM Bookmarks: InitializeManager - Lock RELEASED.", "color: #666; font-weight:bold;");
    }
}


// SPA Navigation Detection & Handling
function spaNavigationHandler(eventSource) {
    console.log(
        `%cLLM Bookmarks: SPA Navigation Event Detected (%c${eventSource}%c) %c
        - New location: ${location.href}.
        - Triggering initializeManager.`,"background-color: magenta; color: white; font-weight: bold; padding: 2px 5px;","background-color: pink; color: black; font-style: italic; padding: 2px 5px;","background-color: magenta; color: white; font-weight: bold; padding: 2px 5px;","background-color: #f8d7da; color: #721c24; padding: 2px 5px;"
    );
    initializeManager(); 
}
window.addEventListener('popstate', () => spaNavigationHandler('popstate'));

(function(history){
    const originalPushState = history.pushState;
    history.pushState = function() {
        const result = originalPushState.apply(history, arguments);
        spaNavigationHandler('pushState');
        return result;
    };
    const originalReplaceState = history.replaceState;
    history.replaceState = function() {
        const result = originalReplaceState.apply(history, arguments);
        spaNavigationHandler('replaceState');
        return result;
    };
})(window.history);

// Initial Load
// DOMContentLoaded is already a form of waiting for DOM, but waitForDOM adds retries.
// We will call initializeManager directly, which now internally uses waitForDOM.
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => {
    console.log("LLM Bookmarks: DOMContentLoaded - Calling initializeManager.");
    initializeManager();
  });
} else {
  console.log("LLM Bookmarks: DOM already loaded / or loading state not 'loading' - Calling initializeManager.");
  initializeManager();
}

// --- Message Listener ---
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  (async () => {
    console.log(`LLM Bookmarks (Message Listener for ${request.action}): Verifying/Re-initializing manager if needed at listener entry.`);
    
    await initializeManager(); 

    if (!bookmarkManager) {
        console.error("LLM Bookmarks: BookmarkManager CRITICAL FAILURE to initialize for action:", request.action);
        sendResponse({ success: false, error: "Bookmark manager component failed to load on page." });
        return;
    }
    
    // Sanity check: After initializeManager, the global bookmarkManager's key *should* match currentManagerKey
    // and also the key derived from the current URL.
    const finalCheckKey = (new BookmarkManager())._sanitizeUrlForKey(window.location.origin + window.location.pathname); // Suppress logs for this temp instance too
    if (currentManagerKey !== finalCheckKey || (bookmarkManager && bookmarkManager.pageKeySuffix !== finalCheckKey)) {
        console.error(
            `%cLLM Bookmarks (Message Listener): FATAL MISMATCH POST-INIT & LOCK! %c
            - Manager Key in instance: ${bookmarkManager ? bookmarkManager.pageKeySuffix : 'N/A'}
            - Tracked currentManagerKey: ${currentManagerKey}
            - Freshly Calculated URL Key: ${finalCheckKey}
            - Action: ${request.action}
            - This indicates a severe issue in manager state synchronization. Cannot safely proceed. Aborting action.`, 
            "background-color: red; color: white; font-weight: bold; padding: 2px 5px;",
            "background-color: #f8d7da; color: #721c24; padding: 2px 5px;"
        );
        sendResponse({ success: false, error: "Bookmark manager state out of sync with page URL. Action aborted." });
        return;
    }

    console.log(
        `%cLLM Bookmarks (Message Listener): Action '${request.action}' will be handled by manager with key: %c${currentManagerKey}`,
        "background-color: #17a2b8; color: white; font-weight: bold; padding: 2px 5px;",
        "background-color: #d1ecf1; color: #0c5460; padding: 2px 5px;"
    );

    try {
      switch (request.action) {
        case 'clearAllBookmarks':
          console.log(`LLM Bookmarks (Message: clearAllBookmarks) for page ${bookmarkManager.pageKeySuffix}, mode ${bookmarkManager.currentPinningMode}`);
          try {
              await bookmarkManager.clearAllBookmarks(); // Call the instance method
              sendResponse({ success: true });
          } catch (error) {
              console.error("LLM Bookmarks: Error clearing bookmarks via manager method:", error);
              sendResponse({ success: false, error: error.message });
          }
          break;
        case 'getBookmarks':
          let bookmarkList = [];
          const modeForList = bookmarkManager.currentPinningMode;
          if (modeForList === 'single') {
            if (bookmarkManager.activeSingleBookmark) bookmarkList.push(bookmarkManager.activeSingleBookmark);
          } else {
            if (bookmarkManager.multipleBookmarks) {
                bookmarkList.push(...Array.from(bookmarkManager.multipleBookmarks.values()).sort((a,b) => (a.displayIndex || Infinity) - (b.displayIndex || Infinity)));
            }
          }
          console.log(`LLM Bookmarks (Message: getBookmarks) for page ${bookmarkManager.pageKeySuffix}. Mode: ${modeForList}. Count: ${bookmarkList.length}`);
          sendResponse({ bookmarks: bookmarkList, mode: modeForList, pageTitle: document.title, pageUrlKey: bookmarkManager.pageKeySuffix });
          break;
        case 'navigateToPrimaryBookmarkAction':
          console.log(`LLM Bookmarks (Message: navigateToPrimaryBookmarkAction) for page ${bookmarkManager.pageKeySuffix}`);
          if (bookmarkManager.currentPinningMode === 'single' && bookmarkManager.activeSingleBookmark) {
            await bookmarkManager.scrollToBookmark(bookmarkManager.activeSingleBookmark.id);
          } else if (bookmarkManager.currentPinningMode === 'multi' && bookmarkManager.multipleBookmarks.size > 0) {
            // Navigate to the first multi-pin by sorted order if this command is used for multi-mode
            const sortedBookmarks = Array.from(bookmarkManager.multipleBookmarks.values()).sort((a,b) => (a.displayIndex || Infinity) - (b.displayIndex || Infinity));
            if (sortedBookmarks.length > 0) {
              await bookmarkManager.scrollToBookmark(sortedBookmarks[0].id);
            }
          } else {
            bookmarkManager.showNotification("No primary bookmark to navigate to.");
          }
          sendResponse({ success: true });
          break;
        case 'navigateToSpecificBookmark':
          console.log(`LLM Bookmarks (Message: navigateToSpecificBookmark) for page ${bookmarkManager.pageKeySuffix}, ID: ${request.bookmarkId}`);
          if (request.bookmarkId) await bookmarkManager.scrollToBookmark(request.bookmarkId);
          sendResponse({ success: true });
          break;
        case 'navigateToSpecificBookmarkByMode':
          console.log(`LLM Bookmarks (Message: navigateToSpecificBookmarkByMode) for page ${bookmarkManager.pageKeySuffix}, Mode: ${request.mode}, Index: ${request.index}`);
          if (request.mode === 'single') {
            if (bookmarkManager.currentPinningMode === 'single' && bookmarkManager.activeSingleBookmark) {
              await bookmarkManager.scrollToBookmark(bookmarkManager.activeSingleBookmark.id);
              sendResponse({ success: true, message: "Navigated to single bookmark." });
            } else {
              bookmarkManager.showNotification("Single pin mode not active or no bookmark set.");
              sendResponse({ success: false, error: "Single pin mode not active or no bookmark." });
            }
          } else if (request.mode === 'multi') {
            if (bookmarkManager.currentPinningMode === 'multi' && request.index && request.index > 0) {
              const sortedBookmarks = Array.from(bookmarkManager.multipleBookmarks.values()).sort((a,b) => (a.displayIndex || Infinity) - (b.displayIndex || Infinity));
              if (request.index <= sortedBookmarks.length) {
                const targetBookmark = sortedBookmarks[request.index - 1]; // 0-indexed access
                await bookmarkManager.scrollToBookmark(targetBookmark.id);
                sendResponse({ success: true, message: `Navigated to multi-bookmark index ${request.index}.` });
              } else {
                bookmarkManager.showNotification(`Bookmark at index ${request.index} not found.`);
                sendResponse({ success: false, error: `Bookmark at index ${request.index} not found.` });
              }
            } else {
              bookmarkManager.showNotification("Multi-pin mode not active or invalid index provided.");
              sendResponse({ success: false, error: "Multi-pin mode not active or invalid index." });
            }
          } else {
            sendResponse({ success: false, error: "Invalid mode for navigation." });
          }
          break;
        case 'syncModeAndData':
          console.log(`LLM Bookmarks (Message: syncModeAndData) for page ${bookmarkManager.pageKeySuffix}, newMode: ${request.newMode}`);
          if (request.newMode) {
            await bookmarkManager.switchToMode(request.newMode);
            sendResponse({ success: true, newMode: request.newMode, message: "全局默认模式已设置，当前页面已同步。" });
          } else {
            sendResponse({ success: false, error: '未指定新模式。' });
          }
          break;
        default:
          console.warn("LLM Bookmarks: Unknown action received in content.js:", request.action);
          sendResponse({ success: false, error: "Unknown action" });
          break;
      }
    } catch (error) {
        console.error(`LLM Bookmarks: Error processing message action '${request.action}' for page ${bookmarkManager ? bookmarkManager.pageKeySuffix : 'UNKNOWN_PAGE'}:`, error);
        sendResponse({ success: false, error: "Internal error: " + error.message });
    }
  })();
  return true;
});