// popup.js - LLM Smart Bookmarks (with Mode Selection)

// Helper functions for safe storage operations
async function safeStorageGetPopup(keys) {
  return new Promise((resolve) => {
    chrome.storage.local.get(keys, (result) => {
      if (chrome.runtime.lastError) {
        console.error("Popup JS: Storage get error (lastError):", chrome.runtime.lastError.message);
        resolve(Array.isArray(keys) ? {} : undefined); // Default empty value on error
      } else {
        resolve(result);
      }
    });
  });
}

async function safeStorageSetPopup(data) {
  return new Promise((resolve) => {
    chrome.storage.local.set(data, () => {
      if (chrome.runtime.lastError) {
        console.error("Popup JS: Storage set error (lastError):", chrome.runtime.lastError.message);
        resolve(false);
      } else {
        resolve(true);
      }
    });
  });
}

function updatePageTitleInPopup(title, pageUrlKey) {
    const pageTitleElement = document.getElementById('page-title-text');
    // const pageUrlKeyElement = document.getElementById('page-url-key'); // 您可以取消注释此行（并确保popup.html中有对应元素）来显示页面键

    if (pageTitleElement) {
        pageTitleElement.textContent = title ? title.substring(0, 70) : 'Page title not available';
        if (title && title.length > 70) {
            pageTitleElement.textContent += "...";
        }
    }
    /* // 如果您决定显示页面键，可以取消注释以下代码块
    if (pageUrlKeyElement) {
        pageUrlKeyElement.textContent = `Key: ${pageUrlKey ? pageUrlKey.substring(0, 30) + (pageUrlKey.length > 30 ? '...' : '') : 'N/A'}`;
    }
    */
    console.log(`Popup JS: Attempted to update page title to "${title}" in popup.`);
}

let isInitializing = false;
let currentBookmarks = [];
let currentPageKey = '';
let currentGlobalPinningMode = 'multi'; // Default, will be updated

// Add listener for updates from content script
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'chatPinStateUpdated') {
        // Check if the update is relevant. The content script that sent this message
        // should be for the active tab where the popup is interacting.
        // We can make this check more robust if needed, but for now, assume relevance.
        console.log('Popup JS: Received chatPinStateUpdated. Refreshing view with data:', request);

        currentGlobalPinningMode = request.mode; 
        currentPageKey = request.pageUrlKey;
        currentBookmarks = request.bookmarks;

        displayBookmarks(request.bookmarks, request.pageUrlKey);
        applyModeToUI(request.mode);
        updatePageTitleInPopup(request.pageTitle || document.title, request.pageUrlKey); 
        
        // No response needed for this type of message
        return false; // Or true if you intend to use sendResponse asynchronously later for some reason
    }
    return true; // Important for other message listeners, or if sendResponse might be used.
});

document.addEventListener('DOMContentLoaded', () => {
  console.log('Popup JS: DOMContentLoaded event fired, popup is opening/refreshing.');

  const bookmarksList = document.getElementById('bookmarks-list');
  const modeMultiRadio = document.getElementById('modeMulti');
  const modeSingleRadio = document.getElementById('modeSingle');
  const pinModeRadios = document.querySelectorAll('input[name="pinMode"]');

  let currentPagePinningMode = 'multi'; 
  const GLOBAL_DEFAULT_MODE_KEY_POPUP = 'globalPinningModePreference'; 

  function applyModeToUI(mode) {
    console.log('Popup JS: applyModeToUI called with mode:', mode);
    currentPagePinningMode = mode || 'multi'; // Ensure currentPagePinningMode is always set
    if (currentPagePinningMode === 'single') {
      if (modeSingleRadio) modeSingleRadio.checked = true;
    } else {
      if (modeMultiRadio) modeMultiRadio.checked = true; 
    }
  }

  async function initializePopupState() {
    console.log("Popup JS: initializePopupState called - this will refresh bookmark data.");
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs && tabs.length > 0 && tabs[0].id && tabs[0].url && !tabs[0].url.startsWith('chrome://')) {
        chrome.tabs.sendMessage(tabs[0].id, { action: 'getBookmarks' }, (response) => {
          console.log('Popup JS (init): GETBOOKMARKS RESPONSE CALLBACK ENTERED.');
          if (chrome.runtime.lastError) {
            console.error("Popup JS (init): Error in getBookmarks response callback (runtime.lastError):", chrome.runtime.lastError.message, "- Likely content script not ready or on restricted page. Falling back to global default.");
            loadGlobalDefaultModeFromStorage(true);
            return;
          }
          if (!response) {
              console.warn("Popup JS (init): Received NO response object (undefined/null) from content script for getBookmarks. This is unexpected if content script sent one. Falling back.");
              showErrorState("No data received from page. Try reloading.");
              loadGlobalDefaultModeFromStorage(true);
              return;
          }
          if (response) {
            if (response.error) {
              showErrorState(`Error from page: ${response.error}`);
              console.warn("Popup JS (init): Content script reported an error:", response.error, "- Falling back.");
              loadGlobalDefaultModeFromStorage(true);
              return;
            }
            console.log("Popup JS (init): Received initial state from content script (raw response):", response);
            console.log("Popup JS (init): Detailed response.bookmarks (JSON):", JSON.stringify(response.bookmarks));
            console.log("Popup JS (init): response.bookmarks type:", typeof response.bookmarks);
            if (response.bookmarks) {
                console.log("Popup JS (init): response.bookmarks length:", response.bookmarks.length);
            }
            
            currentGlobalPinningMode = response.mode; // Store the mode from content script
            currentPageKey = response.pageUrlKey; // Store the page key
            currentBookmarks = response.bookmarks || []; // Store bookmarks

            applyModeToUI(response.mode);
            updatePageTitleInPopup(response.pageTitle || document.title, response.pageUrlKey);

            if (response.bookmarks && Array.isArray(response.bookmarks) && response.bookmarks.length > 0) {
              displayBookmarks(response.bookmarks, response.pageUrlKey);
            } else {
              console.warn("Popup JS (init): response.bookmarks is null, undefined, not a valid array, or empty. Actual value:", response.bookmarks);
              showEmptyState(); 
            }
          } else {
            console.warn("Popup JS (init): No response from content script. This usually means content.js isn't on the page or didn't set up its listener. Falling back.");
            showErrorState("Cannot connect to page script. Try reloading the page.");
            loadGlobalDefaultModeFromStorage(true);
          }
        });
      } else {
        let reason = "Cannot access active tab or tab is restricted.";
        if (tabs && tabs.length > 0 && tabs[0].url && tabs[0].url.startsWith('chrome://')) {
            reason = "Extension cannot run on chrome:// pages.";
        }
        showErrorState(reason);
        console.warn(`Popup JS (init): ${reason}. Falling back to global default mode display.`);
        loadGlobalDefaultModeFromStorage(true);
      }
    });
  }

  async function loadGlobalDefaultModeFromStorage(isInitialUISetup = false) {
      console.log("Popup JS: loadGlobalDefaultModeFromStorage called. isInitialUISetup:", isInitialUISetup);
      const data = await safeStorageGetPopup(GLOBAL_DEFAULT_MODE_KEY_POPUP);
      const globalMode = (data && data[GLOBAL_DEFAULT_MODE_KEY_POPUP]) || 'multi';
      console.log("Popup JS (fallback): Loaded global default mode from storage:", globalMode);
      applyModeToUI(globalMode);
      
      if(isInitialUISetup && bookmarksList && bookmarksList.innerHTML.includes("Loading bookmarks...")) {
          showEmptyState(); 
      }
  }

  if (pinModeRadios && pinModeRadios.length > 0) {
    pinModeRadios.forEach(radio => {
      radio.addEventListener('change', (event) => {
        const newMode = event.target.value;
        console.log("Popup JS: Mode radio changed in UI to:", newMode);

        // Optimistically update UI, but actual state relies on content script sync
        // applyModeToUI(newMode); // This might be too early if sync fails

        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
          if (tabs && tabs.length > 0 && tabs[0].id && tabs[0].url && !tabs[0].url.startsWith('chrome://')) {
            chrome.tabs.sendMessage(
              tabs[0].id, 
              { action: 'syncModeAndData', newMode: newMode }, 
              (response) => {
                console.log('Popup JS (syncMode): SYNCMODEDATA RESPONSE CALLBACK ENTERED.');
                if (chrome.runtime.lastError) {
                  console.error("Popup JS: Error sending syncModeAndData message:", chrome.runtime.lastError.message);
                  showErrorState("Error syncing mode with page. Try refreshing page.");
                  // Re-fetch state to ensure UI consistency
                  initializePopupState(); 
                  return;
                }
                if (!response) {
                    console.warn("Popup JS (syncMode): Received NO response object (undefined/null) from content script for syncModeAndData. Falling back.");
                    showErrorState("Failed to sync: no response from page.");
                    initializePopupState(); // Re-fetch true state
                    return;
                }
                if (response && response.success && response.newMode) {
                  console.log("Popup JS: Content script acknowledged mode sync to:", response.newMode);
                  applyModeToUI(response.newMode); // IMPORTANT: Update UI with confirmed mode
                  loadBookmarks(); // Refresh list now that content script is in the new mode
                } else {
                  console.warn("Popup JS: Content script did not successfully sync mode or invalid response.", response);
                  showErrorState(response?.error || "Failed to sync mode with page.");
                  initializePopupState(); // Re-fetch true state
                }
              }
            );
          } else {
            console.warn("Popup JS: No active/accessible tab. Updating global default pinning mode preference directly.");
            (async () => {
              const success = await safeStorageSetPopup({ [GLOBAL_DEFAULT_MODE_KEY_POPUP]: newMode });
              if (success) {
                console.log("Popup JS: Global pinning mode preference saved directly:", newMode);
                applyModeToUI(newMode);
                showEmptyState(); 
              } else {
                showErrorState("Error saving global mode setting.");
                // Attempt to re-load previous global default
                loadGlobalDefaultModeFromStorage();
              }
            })();
          }
        });
      });
    });
    console.log('Popup JS: Pin mode radio event listeners attached.');
  } else {
    console.error('Popup JS: pinModeRadios not found or is null/empty.');
  }

  function loadBookmarks() {
    console.log("Popup JS: loadBookmarks called.");
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs && tabs.length > 0 && tabs[0].id && tabs[0].url && !tabs[0].url.startsWith('chrome://')) {
            chrome.tabs.sendMessage(
                tabs[0].id,
                { action: 'getBookmarks' },
                (response) => {
                    console.log('Popup JS (loadBookmarks): GETBOOKMARKS RESPONSE CALLBACK ENTERED.');
                    if (chrome.runtime.lastError) {
                        console.error("Popup JS (loadBookmarks): Error sending getBookmarks message:", chrome.runtime.lastError.message);
                        showErrorState("Error loading bookmarks. Try refreshing the page.");
                        return;
                    }
                    if (!response) {
                        console.warn("Popup JS (loadBookmarks): Received NO response object (undefined/null) from content script for getBookmarks. Falling back.");
                        showEmptyState();
                        return;
                    }
                    if (response) {
                        console.log("Popup JS (loadBookmarks): Received bookmarks from content script (raw response):", response);
                        console.log("Popup JS (loadBookmarks): Detailed response.bookmarks (JSON):", JSON.stringify(response.bookmarks));
                        console.log("Popup JS (loadBookmarks): response.bookmarks type:", typeof response.bookmarks);
                        if (response.bookmarks) {
                           console.log("Popup JS (loadBookmarks): response.bookmarks length:", response.bookmarks.length);
                        }

                        currentGlobalPinningMode = response.mode; // Store the mode
                        currentPageKey = response.pageUrlKey; // Store the page key
                        currentBookmarks = response.bookmarks || []; // Store bookmarks

                        applyModeToUI(response.mode);
                        updatePageTitleInPopup(response.pageTitle || document.title, response.pageUrlKey);

                        if (response.bookmarks && Array.isArray(response.bookmarks) && response.bookmarks.length > 0) {
                           displayBookmarks(response.bookmarks, response.pageUrlKey);
                        } else {
                           console.warn("Popup JS (loadBookmarks): response.bookmarks is null, undefined, not a valid array, or empty. Actual value:", response.bookmarks);
                           showEmptyState();
                        }
                    } else {
                        console.warn("Popup JS (loadBookmarks): No response object received from content script.");
                        showEmptyState();
                    }
                }
            );
        } else {
            showErrorState("Cannot access active tab or tab is restricted.");
        }
    });
  }

  function displayBookmarks(bookmarksArray, pageUrlKey) {
    console.log("Popup JS: displayBookmarks called with array length:", bookmarksArray ? bookmarksArray.length : 'null');
    if (!bookmarksList) {
        console.error("Popup JS: bookmarksList element is null in displayBookmarks. Cannot display.");
        return;
    }
    if (!bookmarksArray || bookmarksArray.length === 0) {
      showEmptyState();
      return;
    }
    
    bookmarksList.innerHTML = '';
    bookmarksArray.forEach((bookmark) => {
      const bookmarkElement = document.createElement('div');
      bookmarkElement.className = 'bookmark-item';
      bookmarkElement.dataset.bookmarkId = bookmark.id;
      
      const indexPrefix = (currentPagePinningMode === 'multi' && typeof bookmark.displayIndex === 'number' && bookmark.displayIndex > 0) 
                          ? `<span class="bookmark-index"><b>${bookmark.displayIndex}.</b></span> ` 
                          : '';

      bookmarkElement.innerHTML = `
        ${indexPrefix}
        <span class="bookmark-text">${escapeHtml(bookmark.text)}</span>
        <div class="bookmark-time">Set: ${new Date(bookmark.timestamp).toLocaleString()}</div> 
      `;
      
      bookmarkElement.style.cursor = 'pointer';
      bookmarkElement.title = 'Click to navigate to this bookmark';
      
      bookmarkElement.addEventListener('click', () => {
        console.log("Popup JS: Bookmark item clicked, ID:", bookmark.id);
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
          if (tabs.length > 0 && tabs[0].id && tabs[0].url && !tabs[0].url.startsWith('chrome://')) {
            chrome.tabs.sendMessage(tabs[0].id, { 
              action: 'navigateToSpecificBookmark', 
              bookmarkId: bookmark.id
            }, () => {
                if(chrome.runtime.lastError) {
                    console.warn("Popup JS: Error sending navigateToSpecificBookmark", chrome.runtime.lastError.message);
                }
            });
            window.close(); 
          } else {
              console.warn("Popup JS: Cannot navigate, no accessible active tab.");
          }
        });
      });
      
      bookmarksList.appendChild(bookmarkElement);
    });
  }

  function showEmptyState() {
    console.log("Popup JS: showEmptyState called for mode:", currentPagePinningMode);
    const message = currentPagePinningMode === 'single' ? 
        'No active bookmark set for this page.' : 
        'No bookmarks yet for this page.';
    if (bookmarksList) {
        bookmarksList.innerHTML = `<div class="empty-state">${message}<br>On a webpage, select text and click the 📌 icon that appears to create one.</div>`;
    } else {
        console.error("Popup JS: bookmarksList element not found in showEmptyState.");
    }
  }

  function showErrorState(message) {
    console.log("Popup JS: showErrorState called with message:", message);
    if (bookmarksList) {
        bookmarksList.innerHTML = `<div class="empty-state error">${escapeHtml(message)}<br>Try refreshing the page or the popup.</div>`;
    } else {
        console.error("Popup JS: bookmarksList element not found in showErrorState.");
    }
  }

  function escapeHtml(text) {
    if (typeof text !== 'string') return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }

  console.log("Popup JS: Attaching event listeners and initializing state (which includes auto-refresh).");
  initializePopupState(); // This is the automatic refresh on open
  console.log("Popup JS: Initial setup complete.");
});